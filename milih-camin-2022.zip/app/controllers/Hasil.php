<?php 

class Hasil extends Controller
{
    public function index()
    {
        $this->view('panel');
    }
}