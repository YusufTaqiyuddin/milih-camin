</div>
<script src="<?= $this->assets('js/jquery.js') ?>"></script>
<script src="<?= $this->assets('js/bootstrap.js') ?>"></script>
</body>

</html>