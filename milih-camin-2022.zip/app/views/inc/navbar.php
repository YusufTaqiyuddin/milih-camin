<div class="navbar pt-4 pb-4">
    <div class="navbar-brand">
    <img src="<?= $this->assets("img/solinep.png") ?>" alt="pcc" width="50" height="50">
    </div>

    <div class="navbar-brand d-sm-block d-none">
        <img src="<?= $this->assets("img/pcc.jpg") ?>" alt="pcc" width="50" height="50">
    </div>

    <div class="col-7 col-sm-auto ms-sm-auto text-white h5 text-center">
        PEMILIHAN CALON ADMINISTRATOR PCC
    </div>

    <div class="navbar-brand d-sm-none">
        <img src="pcc.jpg" alt="pcc" width="50" height="50" />
    </div>
</div>