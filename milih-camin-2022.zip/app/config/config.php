<?php
//DB Params
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'camin');
//App Root
define('BASEURL', 'http://localhost/milih-camin-2022/');
//site name
define('SITENAME', 'Pemiihan Admin PCC');

define('DEFAULT_CONTROLLER', 'login');
