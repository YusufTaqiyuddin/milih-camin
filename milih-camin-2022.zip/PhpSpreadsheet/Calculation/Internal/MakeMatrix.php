<?php

namespace PhpOffice\PhpSpreadsheet\Calculation\Internal;

class MakeMatrix
{
    public static function make(...$args): array
    {
        return $args;
    }
}
